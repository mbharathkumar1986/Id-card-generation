import { Hero } from './hero';

export const HEROES: Hero[] = [
  { id: 11, name: 'Nagendra' },
  { id: 12, name: 'Bharath' },
  { id: 13, name: 'KumarRaju' },
  { id: 14, name: 'Surendra' },
  { id: 15, name: 'Phani' },
  { id: 16, name: 'Muni' },
  { id: 17, name: 'Rakul' },
  { id: 18, name: 'Tamman' },
  { id: 19, name: 'Mahesh' },
  { id: 20, name: 'Prabash' }
];
